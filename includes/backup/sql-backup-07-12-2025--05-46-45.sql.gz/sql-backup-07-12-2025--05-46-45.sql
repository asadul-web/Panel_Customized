-- Database: `vpnpanel` --
-- Table `activity_logs` --
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(50) NOT NULL,
  `date` datetime NOT NULL,
  `action` varchar(255) CHARACTER SET latin1 NOT NULL,
  `ipaddress` varchar(20) CHARACTER SET latin1 NOT NULL,
  `device_os` varchar(100) CHARACTER SET latin1 NOT NULL,
  `device_client` varchar(100) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=186 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `activity_logs` (`id`, `user_id`, `date`, `action`, `ipaddress`, `device_os`, `device_client`) VALUES
(98, 1, '2025-12-03 19:07:53', 'Added new user <code>54718 - normal</code>', '::1', 'Windows 10 - Chrome', 'Desktop'),
(99, 1, '2025-12-06 18:28:56', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(100, 1, '2025-12-06 18:44:03', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(101, 2, '2025-12-06 18:44:07', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(102, 1, '2025-12-06 21:04:46', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(103, 1, '2025-12-06 21:15:23', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(104, 2, '2025-12-06 21:15:26', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(105, 2, '2025-12-06 21:32:32', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(106, 2, '2025-12-06 21:32:41', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(107, 2, '2025-12-06 21:39:31', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(108, 1, '2025-12-06 21:39:41', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(109, 1, '2025-12-06 21:40:00', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(110, 1, '2025-12-06 21:40:04', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(111, 1, '2025-12-06 21:42:58', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(112, 1, '2025-12-06 21:43:14', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(113, 2, '2025-12-06 22:13:33', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(114, 2, '2025-12-06 22:14:13', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(115, 2, '2025-12-06 22:14:35', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(116, 1, '2025-12-06 22:14:40', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(117, 2, '2025-12-06 22:15:12', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(118, 2, '2025-12-06 22:15:37', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(119, 1, '2025-12-06 22:15:52', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(120, 1, '2025-12-06 22:21:36', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(121, 1, '2025-12-06 22:22:11', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(122, 1, '2025-12-06 22:23:37', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(123, 1, '2025-12-06 23:36:19', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(124, 2, '2025-12-06 23:36:24', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(125, 1, '2025-12-06 23:47:50', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(126, 1, '2025-12-06 23:48:02', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(127, 2, '2025-12-06 23:48:18', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(128, 2, '2025-12-07 00:34:41', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(129, 1, '2025-12-07 00:34:46', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(130, 1, '2025-12-07 00:35:06', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(131, 57734, '2025-12-07 00:37:00', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(132, 57734, '2025-12-07 00:37:08', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(133, 57734, '2025-12-07 00:42:32', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(134, 57734, '2025-12-07 00:42:41', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(135, 1, '2025-12-07 00:46:09', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(136, 1, '2025-12-07 01:01:59', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(137, 1, '2025-12-07 01:02:10', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(138, 2, '2025-12-07 01:02:21', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(139, 2, '2025-12-07 01:02:53', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(140, 1, '2025-12-07 01:03:12', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(141, 1, '2025-12-07 01:06:31', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(142, 1, '2025-12-07 01:06:35', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(143, 1, '2025-12-07 01:06:45', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(144, 57734, '2025-12-07 01:06:52', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(145, 57734, '2025-12-07 01:07:00', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(146, 1, '2025-12-07 01:07:04', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(147, 1, '2025-12-07 01:09:06', 'Website Login', '::1', 'Android - Chrome', 'Smartphone (Android)'),
(148, 1, '2025-12-07 01:11:05', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(149, 1, '2025-12-07 01:11:06', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(150, 2, '2025-12-07 01:24:44', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(151, 2, '2025-12-07 01:36:35', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(152, 1, '2025-12-07 16:15:45', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(153, 1, '2025-12-07 16:15:58', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(154, 2, '2025-12-07 16:16:02', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(155, 2, '2025-12-07 16:16:10', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(156, 1, '2025-12-07 16:16:19', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(157, 1, '2025-12-07 16:16:44', 'Added <code>reseller</code> as new reseller with <code>1</code> credit balance.', '::1', 'Windows 10 - Chrome', 'Desktop'),
(158, 1, '2025-12-07 16:16:50', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(159, 57750, '2025-12-07 16:16:54', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(160, 57750, '2025-12-07 16:27:32', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(161, 1, '2025-12-07 16:27:35', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(162, 1, '2025-12-07 16:28:44', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(163, 1, '2025-12-07 16:36:31', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(164, 1, '2025-12-07 16:36:52', 'Added new user <code>66743 - normal</code>', '::1', 'Windows 10 - Chrome', 'Desktop'),
(165, 1, '2025-12-07 16:37:25', 'Added <code>reseller4</code> as new reseller with <code>1</code> credit balance.', '::1', 'Windows 10 - Chrome', 'Desktop'),
(166, 1, '2025-12-07 16:39:50', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(167, 1, '2025-12-07 16:40:36', 'Updated <code>66743</code> password.', '::1', 'Windows 10 - Chrome', 'Desktop'),
(168, 1, '2025-12-07 16:40:45', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(169, 2, '2025-12-07 16:40:50', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(170, 2, '2025-12-07 16:41:12', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(171, 1, '2025-12-07 16:41:20', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(172, 1, '2025-12-07 16:41:30', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(173, 2, '2025-12-07 16:41:34', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(174, 2, '2025-12-07 17:37:31', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(175, 1, '2025-12-07 17:38:14', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(176, 1, '2025-12-07 17:38:26', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(177, 2, '2025-12-07 17:38:31', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(178, 2, '2025-12-07 17:39:06', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(179, 2, '2025-12-07 17:40:22', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(180, 1, '2025-12-07 17:40:31', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(181, 2, '2025-12-07 17:41:00', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(182, 2, '2025-12-07 17:45:23', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(183, 2, '2025-12-07 17:45:26', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop'),
(184, 2, '2025-12-07 17:45:45', 'Logout', '::1', 'Google Chrome', 'Web Browser'),
(185, 2, '2025-12-07 17:45:46', 'Website Login', '::1', 'Windows 10 - Chrome', 'Desktop');

-- Table `ads_api_logs` --
CREATE TABLE `ads_api_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(100) NOT NULL,
  `endpoint` varchar(200) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `request_data` text DEFAULT NULL,
  `response_code` int(3) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `app_name` (`app_name`),
  KEY `created_date` (`created_date`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

INSERT INTO `ads_api_logs` (`id`, `app_name`, `endpoint`, `ip_address`, `user_agent`, `request_data`, `response_code`, `created_date`) VALUES
(4, 'SampleApp2', '/api/ads/SampleApp2/config', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '/api/ads/SampleApp2/config', 404, '2025-11-11 14:23:11'),
(10, 'ruzain', '/api/ads/ruzain/config', '::1', 'colly - https://github.com/gocolly/colly', '/api/ads/ruzain/config', 200, '2025-11-13 20:39:24'),
(11, 'ruzain', '/api/ads/ruzain/config', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '/api/ads/ruzain/config', 200, '2025-11-13 20:39:52'),
(12, 'ruzain', '/api/ads/ruzain/config', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '/api/ads/ruzain/config', 200, '2025-11-13 20:41:03');

-- Table `ads_apps` --
CREATE TABLE `ads_apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(100) NOT NULL,
  `package_name` varchar(150) NOT NULL,
  `admob_app_id` varchar(100) NOT NULL,
  `banner_ad_id` varchar(100) DEFAULT NULL,
  `interstitial_ad_id` varchar(100) DEFAULT NULL,
  `rewarded_ad_id` varchar(100) DEFAULT NULL,
  `native_advanced_ad_id` varchar(100) DEFAULT NULL,
  `app_open_ad_id` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive','testing') DEFAULT 'active',
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_name` (`app_name`),
  UNIQUE KEY `package_name` (`package_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `ads_apps` (`id`, `app_name`, `package_name`, `admob_app_id`, `banner_ad_id`, `interstitial_ad_id`, `rewarded_ad_id`, `native_advanced_ad_id`, `app_open_ad_id`, `status`, `created_date`, `updated_date`) VALUES
(6, 'ruzain', 'com.zeroos.app', 'ca-app-pub-3940256099942544~3347511713', 'ca-app-pub-3940256099942544/6300978111', 'ca-app-pub-3940256099942544/1033173712', 'ca-app-pub-3940256099942544/5224354917', 'ca-app-pub-3940256099942544/3986624511', 'ca-app-pub-3940256099942544/5662855259', 'active', '2025-11-13 20:36:21', '2025-11-13 20:36:21');

-- Table `ads_revenue` --
CREATE TABLE `ads_revenue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `app_name` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `ad_type` enum('banner','interstitial','rewarded','native_advanced','app_open','all') DEFAULT 'all',
  `revenue` decimal(10,2) DEFAULT 0.00,
  `impressions` int(11) DEFAULT 0,
  `clicks` int(11) DEFAULT 0,
  `ctr` decimal(5,2) DEFAULT 0.00,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `app_id` (`app_id`),
  KEY `app_name` (`app_name`),
  KEY `date` (`date`),
  CONSTRAINT `ads_revenue_ibfk_1` FOREIGN KEY (`app_id`) REFERENCES `ads_apps` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

-- Table `anti_ddos` --
CREATE TABLE `anti_ddos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `ip` varchar(128) NOT NULL DEFAULT '0.0.0.0',
  `timestamp` int(11) NOT NULL,
  `logs_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Table `app_notices` --
CREATE TABLE `app_notices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notice_type` enum('info','warning','success','error','update') COLLATE utf8mb4_unicode_ci DEFAULT 'info',
  `is_active` tinyint(1) DEFAULT 1,
  `show_button` tinyint(1) DEFAULT 0,
  `button_text` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table `application` --
CREATE TABLE `application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `application` (`id`, `name`, `link`, `date`, `description`, `status`) VALUES
(1, 'Android App', 'https://play.google.com/store/apps', '2025-11-14 18:12:06', 'Android VPN Application', 'active'),
(2, 'iOS App', 'https://apps.apple.com/', '2025-11-14 18:12:06', 'iOS VPN Application', 'active'),
(3, 'Windows App', 'https://example.com/windows', '2025-11-14 18:12:06', 'Windows VPN Client', 'active');

-- Table `applications` --
CREATE TABLE `applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_title` varchar(155) CHARACTER SET latin1 NOT NULL,
  `app_version` varchar(11) CHARACTER SET latin1 NOT NULL,
  `app_website` varchar(155) CHARACTER SET latin1 NOT NULL,
  `logo` varchar(55) CHARACTER SET latin1 NOT NULL,
  `app_description` varchar(55) CHARACTER SET latin1 NOT NULL,
  `filename` varchar(255) CHARACTER SET latin1 NOT NULL,
  `date_uploaded` datetime NOT NULL DEFAULT current_timestamp(),
  `downloads` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `attention` --
CREATE TABLE `attention` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attention_msg` text NOT NULL,
  `attention_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `bandwidth_logs` --
CREATE TABLE `bandwidth_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server` text NOT NULL,
  `server_ip` text NOT NULL,
  `server_port` text NOT NULL,
  `since_connected` text NOT NULL,
  `username` text NOT NULL,
  `ipaddress` text NOT NULL,
  `bytes_received` text NOT NULL,
  `bytes_sent` text NOT NULL,
  `bandwidth` bigint(50) NOT NULL DEFAULT 0,
  `time` datetime NOT NULL,
  `time_in` datetime NOT NULL,
  `time_out` datetime NOT NULL,
  `status` enum('offline','online') NOT NULL,
  `timestamp` int(11) NOT NULL,
  `category` enum('premium','vip','ph','private','free') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `chat` --
CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_id1` int(11) NOT NULL,
  `chat_id2` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_status` enum('seen','unseen') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unseen',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `sender_type` enum('user','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  KEY `chat_id1` (`chat_id1`),
  KEY `chat_id2` (`chat_id2`),
  KEY `chat_status` (`chat_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table `conversion_logs` --
CREATE TABLE `conversion_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `premium` varchar(755) NOT NULL,
  `vip` varchar(755) NOT NULL,
  `description` varchar(755) NOT NULL,
  `logs_date` datetime NOT NULL,
  `ipaddress` varchar(32) NOT NULL DEFAULT '0.0.0.0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `credits_logs` --
CREATE TABLE `credits_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credits_id` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `credits_id2` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `credits_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `credits_qty` int(11) NOT NULL,
  `credits_date` datetime NOT NULL,
  `seller` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `credits_logs` (`id`, `credits_id`, `credits_id2`, `credits_type`, `credits_qty`, `credits_date`, `seller`) VALUES
(66, '1', 'reseller', 'add', 1, '2025-11-24 02:58:56', ''),
(67, '1', 'reseller4', 'add', 1, '2025-11-24 03:04:24', ''),
(68, '1', 'Bhffh', 'add', 20, '2025-11-25 11:12:32', ''),
(69, '1', 'reseller4', 'add', 999999, '2025-11-25 18:54:20', ''),
(70, '1', 'reseller', 'add', 1, '2025-11-27 22:26:09', ''),
(71, '1', 'reseller', 'transfer', 2, '2025-11-27 22:26:23', ''),
(72, '1', 'reseller5', 'add', 1, '2025-11-29 17:55:53', ''),
(73, '1', 'reseller', 'add', 1, '2025-12-07 16:16:44', ''),
(74, '1', 'reseller4', 'add', 1, '2025-12-07 16:37:25', '');

-- Table `cronjob_banned_ip` --
CREATE TABLE `cronjob_banned_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `content` varchar(128) NOT NULL DEFAULT 'Attempting',
  `ip` varchar(128) NOT NULL DEFAULT '0.0.0.0',
  `logs_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Table `cronjob_logs` --
CREATE TABLE `cronjob_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `ipaddress` varchar(128) NOT NULL DEFAULT '0.0.0.0',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `deleted_app_logs` --
CREATE TABLE `deleted_app_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `app_title` varchar(55) CHARACTER SET latin1 NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_deleted` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `deleted_logs` --
CREATE TABLE `deleted_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(50) NOT NULL,
  `user_upline` int(50) NOT NULL,
  `user_level` varchar(50) CHARACTER SET latin1 NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7397 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `deleted_logs` (`id`, `user_id`, `user_upline`, `user_level`, `date`) VALUES
(7392, 57739, 1, 'normal', '2025-11-25 11:13:33'),
(7393, 57740, 1, 'reseller', '2025-11-25 11:14:23'),
(7394, 57738, 1, 'normal', '2025-11-27 18:49:06'),
(7395, 57737, 1, 'normal', '2025-11-27 18:49:47'),
(7396, 57736, 1, 'reseller', '2025-11-27 22:26:48');

-- Table `dns` --
CREATE TABLE `dns` (
  `dns_id` int(255) NOT NULL AUTO_INCREMENT,
  `record_id` varchar(50) CHARACTER SET latin1 NOT NULL,
  `host_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `domain_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `ip_address` varchar(50) CHARACTER SET latin1 NOT NULL,
  `record_type` varchar(50) CHARACTER SET latin1 NOT NULL,
  `status` int(10) NOT NULL,
  `global_api` varchar(255) CHARACTER SET latin1 NOT NULL,
  `zone_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `email` varchar(155) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`dns_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=65019 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `download` --
CREATE TABLE `download` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `download_category` enum('public','seller') NOT NULL,
  `download_title` varchar(767) NOT NULL,
  `download_msg` text NOT NULL,
  `download_network` enum('NOTICE','UPDATE') NOT NULL,
  `download_device` enum('ANDROID','IOS','WINDOWS','CONFIG','OTHERS') NOT NULL,
  `download_file` varchar(999) NOT NULL,
  `download_date` datetime NOT NULL,
  `views` int(11) NOT NULL DEFAULT 0,
  `downloaded` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

INSERT INTO `download` (`id`, `download_category`, `download_title`, `download_msg`, `download_network`, `download_device`, `download_file`, `download_date`, `views`, `downloaded`) VALUES
(14, 'public', 'Welcome to Vollam', 'The entire team of Vollam is thrilled to welcome you on board. We hope you&rsquo;ll do some amazing works here!&nbsp;<br /><br />Congratulations on being part of the team! The whole team welcomes you and we look forward to a successful journey with you! Welcome aboard!', 'NOTICE', 'OTHERS', '', '2020-12-13 10:01:13', 0, 0),
(15, 'public', 'How to update Vollam applications', 'Vollam applications get staged automatic updates. It means that some users get their automatic&nbsp;updates earlier than others. The reason for that is to avoid massive issues in case&nbsp;of some failure related to the updates.<br /><br />If you haven&#39;t got an automatic update yet, you will get it within a few days. If you wish to get the latest app version now, you can download it from our&nbsp;News and Updates section. The download page always provides&nbsp;the latest available app versions for all operating systems.', 'NOTICE', 'OTHERS', '', '2020-12-11 17:35:19', 0, 0),
(16, 'public', 'VPN for Netflix: watch Netflix securely', '<p>To ensure&nbsp;secure access to Netflix, you can connect to&nbsp;<strong>any of our servers&nbsp;listed below</strong>. We recommend using the servers closest to your location for the best connection speed and stability.<br /><br /><strong>Netflix US:</strong><br />You should connect to any of our servers in countries&nbsp;<strong>other than</strong>&nbsp;Canada, Germany, the United Kingdom, France, Italy, Japan, Australia, the Netherlands, India, Brazil, Spain, Portugal, South Korea, and Finland.</p><p><strong>Netflix CA:</strong><br />You should connect to any of our servers in Canada.</p><p><strong>Netflix DE:</strong><br />You should connect to any of our servers in Germany.</p>', 'NOTICE', 'OTHERS', '', '2020-12-11 17:35:46', 0, 0),
(46, 'public', 'Test Update with APK', 'Test Notice and Update with apk file attachment.', 'UPDATE', 'ANDROID', '1605592512.apk', '2020-11-17 13:55:12', 0, 0);

-- Table `duration` --
CREATE TABLE `duration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `duration_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `duration_time` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `duration` (`id`, `duration_name`, `duration_time`) VALUES
(1, '1 Hour', 3600),
(2, '2 Hours', 7200),
(3, '3 Hours', 10800),
(4, '4 Hours', 14400),
(5, '5 Hours', 18000),
(6, '6 Hours', 21600),
(7, '7 Hours', 25200),
(8, '8 Hours', 28800),
(9, '9 Hours', 32400),
(10, '10 Hours', 36000),
(11, '11 Hours', 39600),
(12, '12 Hours', 43200),
(13, '13 Hours', 46800),
(14, '14 Hours', 50400),
(15, '15 Hours', 54000),
(16, '16 Hours', 57600),
(17, '17 Hours', 61200),
(18, '18 Hours', 64800),
(19, '19 Hours', 68400),
(20, '20 Hours', 72000),
(21, '21 Hours', 75600),
(22, '22 Hours', 79200),
(23, '23 Hours', 82800),
(24, '1 Day', 86400),
(25, '2 Days', 172800),
(26, '3 Days', 259200),
(27, '4 Days', 345600),
(28, '5 Days', 432000),
(29, '6 Days', 518400),
(30, '7 Days', 604800),
(31, '8 Days', 691200),
(32, '9 Days', 777600),
(33, '10 Days', 864000),
(34, '15 Days', 1296000),
(35, '20 Days', 1728000),
(36, '30 Days', 2592000),
(37, '31 Days', 2678400),
(38, '32 Days', 2764800),
(39, '-3 Days', -259200);

-- Table `duration_logs` --
CREATE TABLE `duration_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `duration_id` int(11) NOT NULL,
  `duration_id2` int(11) NOT NULL,
  `duration_username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duration_qty` int(11) NOT NULL,
  `duration_item` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duration_date` datetime NOT NULL,
  `duration_type` enum('premium','vip','private') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'premium',
  `ipaddress` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0.0.0.0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `email_campaign_recipients` --
CREATE TABLE `email_campaign_recipients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_id` int(11) NOT NULL,
  `subscriber_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` enum('pending','sent','failed','opened','clicked','unsubscribed','bounced') DEFAULT 'pending',
  `sent_date` datetime DEFAULT NULL,
  `opened_date` datetime DEFAULT NULL,
  `clicked_date` datetime DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `tracking_token` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_subscriber` (`campaign_id`,`subscriber_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `subscriber_id` (`subscriber_id`),
  KEY `status` (`status`),
  KEY `tracking_token` (`tracking_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table `email_campaigns` --
CREATE TABLE `email_campaigns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `content_type` enum('html','text') DEFAULT 'html',
  `status` enum('draft','scheduled','sending','sent','paused') DEFAULT 'draft',
  `created_by` int(11) NOT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `updated_date` datetime DEFAULT NULL,
  `scheduled_date` datetime DEFAULT NULL,
  `sent_date` datetime DEFAULT NULL,
  `total_recipients` int(11) DEFAULT 0,
  `recipient_type` varchar(50) DEFAULT 'all',
  `emails_sent` int(11) DEFAULT 0,
  `emails_failed` int(11) DEFAULT 0,
  `opens` int(11) DEFAULT 0,
  `clicks` int(11) DEFAULT 0,
  `unsubscribes` int(11) DEFAULT 0,
  `bounces` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `created_by` (`created_by`),
  KEY `created_date` (`created_date`),
  KEY `idx_status` (`status`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_created_date` (`created_date`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4;

INSERT INTO `email_campaigns` (`id`, `name`, `subject`, `content`, `content_type`, `status`, `created_by`, `created_date`, `updated_date`, `scheduled_date`, `sent_date`, `total_recipients`, `recipient_type`, `emails_sent`, `emails_failed`, `opens`, `clicks`, `unsubscribes`, `bounces`) VALUES
(36, 'VPN Panel Selling offer', 'Special Offer Just for You!', '<meta charset=\"UTF-8\"><style>body{font-family:Arial,sans-serif;margin:0;padding:20px;background:#f4f4f4}.container{max-width:600px;margin:0 auto;background:white;padding:30px;border-radius:8px}.promo{background:#28a745;color:white;padding:20px;text-align:center;border-radius:8px;margin:20px 0}</style><div class=\"container\"><h1>? Special Offer!</h1><div class=\"promo\"><h2>50% OFF</h2><p>Limited time offer for {name}</p></div><p>Don\'t miss out on this amazing deal!</p><p>Best regards,<br>The Sales Team</p></div>', 'html', 'sent', 0, '2025-11-14 16:10:51', '2025-11-14 16:10:59', '', '2025-11-14 16:10:59', 2, 'all', 2, 0, 0, 0, 0, 0),
(37, 'Admin', '???? Limited Time: 50% OFF Premium VPN Plans!', '<meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <style>\n        body { margin: 0; padding: 0; font-family: Arial, sans-serif; background: linear-gradient(45deg, #ff6b6b, #feca57); }\n        .container { max-width: 600px; margin: 0 auto; background: white; }\n        .header { background: linear-gradient(45deg, #ff6b6b, #feca57); padding: 40px 20px; text-align: center; color: white; }\n        .offer-badge { background: #ff4757; color: white; padding: 10px 20px; border-radius: 50px; display: inline-block; font-weight: bold; margin: 10px 0; }\n        .content { padding: 40px 30px; text-align: center; }\n        .price-box { background: #f1f2f6; padding: 30px; border-radius: 15px; margin: 30px 0; }\n        .old-price { text-decoration: line-through; color: #999; font-size: 18px; }\n        .new-price { color: #ff4757; font-size: 36px; font-weight: bold; }\n        .cta-button { background: linear-gradient(45deg, #ff6b6b, #feca57); color: white; padding: 20px 40px; text-decoration: none; border-radius: 50px; font-size: 18px; font-weight: bold; display: inline-block; margin: 20px 0; }\n        .countdown { background: #2f3542; color: white; padding: 20px; border-radius: 10px; margin: 20px 0; }\n        .footer { background: #2f3542; color: white; padding: 20px; text-align: center; }\n    </style>\n\n\n    <div class=\"container\">\n        <div class=\"header\">\n            <div class=\"offer-badge\">LIMITED TIME OFFER</div>\n            <h1>???? MEGA SALE</h1>\n            <h2>50% OFF Everything!</h2>\n        </div>\n        <div class=\"content\">\n            <p>Hi {name},</p>\n            <p>This is your chance to get premium VPN protection at an unbeatable price!</p>\n            \n            <div class=\"price-box\">\n                <h3>Premium Annual Plan</h3>\n                <div class=\"old-price\">$99.99/year</div>\n                <div class=\"new-price\">$49.99/year</div>\n                <p><strong>Save $50 instantly!</strong></p>\n            </div>\n            \n            <div class=\"countdown\">\n                <h3>⏰ Hurry! Offer expires in:</h3>\n                <p style=\"font-size: 24px; margin: 0;\"><strong>48 HOURS</strong></p>\n            </div>\n            \n            <a href=\"{website_url}\" class=\"cta-button\">Claim Your 50% Discount</a>\n            \n            <p><strong>What you get:</strong></p>\n            <p>✅ Unlimited bandwidth<br>\n            ✅ 100+ server locations<br>\n            ✅ 24/7 customer support<br>\n            ✅ 30-day money-back guarantee</p>\n            \n            <p><em>No coupon code needed - discount applied automatically!</em></p>\n        </div>\n        <div class=\"footer\">\n            <p>This offer is exclusive to our subscribers</p>\n            <p><a href=\"{unsubscribe_url}\" style=\"color: #a4b0be;\">Unsubscribe</a></p>\n        </div>\n    </div>', 'html', 'sent', 0, '2025-11-15 13:59:32', '2025-11-15 13:59:43', '', '2025-11-15 13:59:43', 2, 'all', 2, 0, 0, 0, 0, 0);

-- Table `email_subscribers` --
CREATE TABLE `email_subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `status` enum('active','unsubscribed','bounced') DEFAULT 'active',
  `source` varchar(50) DEFAULT 'manual',
  `tags` text DEFAULT NULL,
  `subscribed_date` datetime DEFAULT current_timestamp(),
  `unsubscribed_date` datetime DEFAULT NULL,
  `last_email_sent` datetime DEFAULT NULL,
  `email_count` int(11) DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `subscribed_date` (`subscribed_date`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `email_subscribers` (`id`, `email`, `name`, `status`, `source`, `tags`, `subscribed_date`, `unsubscribed_date`, `last_email_sent`, `email_count`, `ip_address`, `user_agent`) VALUES
(2, 'azimaxus@gmail.com', 'Admin', 'active', 'manual', 'vpn', '2025-11-12 14:52:27', '', '2025-11-15 13:59:37', 20, '::1', ''),
(4, 'datasoftcaresales@gmail.com', 'Anoarul', 'active', 'manual', 'vpn', '2025-11-12 21:14:26', '', '2025-11-15 13:59:43', 20, '::1', '');

-- Table `email_templates` --
CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `content_type` enum('html','text') DEFAULT 'html',
  `template_type` enum('newsletter','promotion','announcement','welcome','custom') DEFAULT 'custom',
  `created_by` int(11) NOT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `updated_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `template_type` (`template_type`),
  KEY `created_by` (`created_by`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;

INSERT INTO `email_templates` (`id`, `name`, `subject`, `content`, `content_type`, `template_type`, `created_by`, `created_date`, `updated_date`, `is_active`) VALUES
(1, 'Welcome Newsletter', 'Welcome to Our VPN Service!', '<h2>Welcome to Our VPN Service!</h2>\n<p>Hello {name},</p>\n<p>Thank you for your interest in our VPN service. We are excited to have you join our community!</p>\n<p>Here is what you can expect:</p>\n<ul>\n<li>Fast and secure VPN connections</li>\n<li>Multiple server locations worldwide</li>\n<li>24/7 customer support</li>\n<li>Easy-to-use applications</li>\n</ul>\n<p><a href=\"{website_url}\">Visit Our Website</a></p>\n<p>You received this email because you subscribed to our newsletter.</p>\n<p><a href=\"{unsubscribe_url}\">Unsubscribe</a></p>', 'html', 'welcome', 1, '2025-11-12 14:37:43', '2025-11-12 14:37:43', '1'),
(2, 'Admin', 'xxxxx', 'xxxxxxx', 'html', 'promotion', 1, '2025-11-12 15:27:52', '2025-11-12 15:27:52', '1'),
(4, 'Welcome Newsletter (Copy 2)', 'Welcome to Our VPN Service!', '<h2>Welcome to Our VPN Service!</h2>\n<p>Hello {name},</p>\n<p>Thank you for your interest in our VPN service. We are excited to have you join our community!</p>\n<p>Here is what you can expect:</p>\n<ul>\n<li>Fast and secure VPN connections</li>\n<li>Multiple server locations worldwide</li>\n<li>24/7 customer support</li>\n<li>Easy-to-use applications</li>\n</ul>\n<p><a href=\"{website_url}\">Visit Our Website</a></p>\n<p>You received this email because you subscribed to our newsletter.</p>\n<p><a href=\"{unsubscribe_url}\">Unsubscribe</a></p>', 'html', 'welcome', 1, '2025-11-12 15:33:30', '2025-11-12 15:33:30', '1'),
(14, 'Modern Welcome Email', 'Welcome to {website_name} - Your VPN Journey Starts Here!', '<meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <style>\n        body { margin: 0; padding: 0; font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }\n        .container { max-width: 600px; margin: 0 auto; background: white; }\n        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 20px; text-align: center; }\n        .header h1 { color: white; margin: 0; font-size: 28px; }\n        .content { padding: 40px 30px; }\n        .welcome-box { background: #f8f9ff; border-left: 4px solid #667eea; padding: 20px; margin: 20px 0; }\n        .btn { display: inline-block; background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; margin: 20px 0; }\n        .features { display: flex; flex-wrap: wrap; gap: 20px; margin: 30px 0; }\n        .feature { flex: 1; min-width: 150px; text-align: center; padding: 20px; background: #f8f9ff; border-radius: 10px; }\n        .footer { background: #333; color: white; padding: 30px; text-align: center; }\n    </style>\n\n\n    <div class=\"container\">\n        <div class=\"header\">\n            <h1>???? Welcome Aboard!</h1>\n        </div>\n        <div class=\"content\">\n            <div class=\"welcome-box\">\n                <h2>Hello {name}!</h2>\n                <p>Welcome to our premium VPN service! We are excited to have you join our community of privacy-conscious users.</p>\n            </div>\n            \n            <div class=\"features\">\n                <div class=\"feature\">\n                    <h3>???? Secure</h3>\n                    <p>Military-grade encryption</p>\n                </div>\n                <div class=\"feature\">\n                    <h3>⚡ Fast</h3>\n                    <p>Lightning-fast servers</p>\n                </div>\n                <div class=\"feature\">\n                    <h3>???? Global</h3>\n                    <p>Servers worldwide</p>\n                </div>\n            </div>\n            \n            <p>Your account is now active and ready to use. Click the button below to get started:</p>\n            <a href=\"{website_url}\" class=\"btn\">Get Started Now</a>\n            \n            <p>If you have any questions, our 24/7 support team is here to help!</p>\n        </div>\n        <div class=\"footer\">\n            <p>© 2024 VPN Service. All rights reserved.</p>\n            <p><a href=\"{unsubscribe_url}\" style=\"color: #ccc;\">Unsubscribe</a></p>\n        </div>\n    </div>', 'html', 'welcome', 1, '2025-11-12 16:52:53', '2025-11-12 17:20:31', '1'),
(23, 'Newsletter - Tech Updates', '???? Weekly Tech Updates & VPN News', '<meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <style>\n        body { margin: 0; padding: 0; font-family: \"Segoe UI\", Arial, sans-serif; background: #f4f4f4; }\n        .container { max-width: 600px; margin: 0 auto; background: white; box-shadow: 0 0 20px rgba(0,0,0,0.1); }\n        .header { background: #2c3e50; color: white; padding: 30px; text-align: center; }\n        .content { padding: 30px; }\n        .article { border-bottom: 1px solid #eee; padding: 20px 0; }\n        .article:last-child { border-bottom: none; }\n        .article h3 { color: #2c3e50; margin-top: 0; }\n        .read-more { color: #3498db; text-decoration: none; font-weight: bold; }\n        .stats { background: #ecf0f1; padding: 20px; border-radius: 10px; margin: 20px 0; }\n        .footer { background: #34495e; color: white; padding: 20px; text-align: center; }\n    </style>\n\n\n    <div class=\"container\">\n        <div class=\"header\">\n            <h1>???? Weekly Newsletter</h1>\n            <p>Stay updated with the latest in VPN technology</p>\n        </div>\n        <div class=\"content\">\n            <p>Hi {name},</p>\n            \n            <div class=\"stats\">\n                <h3>???? This Week in Numbers</h3>\n                <p>• 50,000+ new users joined<br>\n                • 99.9% uptime maintained<br>\n                • 15 new server locations added</p>\n            </div>\n            \n            <div class=\"article\">\n                <h3>???? New Security Features Released</h3>\n                <p>We have enhanced our encryption protocols with the latest WireGuard technology, providing even faster and more secure connections.</p>\n                <a href=\"{website_url}\" class=\"read-more\">Read More →</a>\n            </div>\n            \n            <div class=\"article\">\n                <h3>???? Server Expansion Update</h3>\n                <p>New servers are now live in Tokyo, Sydney, and São Paulo, bringing our total to over 100 locations worldwide.</p>\n                <a href=\"{website_url}\" class=\"read-more\">View All Locations →</a>\n            </div>\n            \n            <div class=\"article\">\n                <h3>???? Privacy Tip of the Week</h3>\n                <p>Always use HTTPS websites when browsing. Look for the lock icon in your browser address bar to ensure your connection is encrypted.</p>\n            </div>\n        </div>\n        <div class=\"footer\">\n            <p>Thank you for being part of our community!</p>\n            <p><a href=\"{unsubscribe_url}\" style=\"color: #bdc3c7;\">Unsubscribe</a> | <a href=\"{website_url}\" style=\"color: #bdc3c7;\">Visit Website</a></p>\n        </div>\n    </div>', 'html', 'newsletter', 1, '2025-11-12 17:24:46', '2025-11-12 17:24:46', '1'),
(24, 'c', '???? Limited Time: 50% OFF Premium VPN Plans!', '<meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <style>\n        body { margin: 0; padding: 0; font-family: Arial, sans-serif; background: linear-gradient(45deg, #ff6b6b, #feca57); }\n        .container { max-width: 600px; margin: 0 auto; background: white; }\n        .header { background: linear-gradient(45deg, #ff6b6b, #feca57); padding: 40px 20px; text-align: center; color: white; }\n        .offer-badge { background: #ff4757; color: white; padding: 10px 20px; border-radius: 50px; display: inline-block; font-weight: bold; margin: 10px 0; }\n        .content { padding: 40px 30px; text-align: center; }\n        .price-box { background: #f1f2f6; padding: 30px; border-radius: 15px; margin: 30px 0; }\n        .old-price { text-decoration: line-through; color: #999; font-size: 18px; }\n        .new-price { color: #ff4757; font-size: 36px; font-weight: bold; }\n        .cta-button { background: linear-gradient(45deg, #ff6b6b, #feca57); color: white; padding: 20px 40px; text-decoration: none; border-radius: 50px; font-size: 18px; font-weight: bold; display: inline-block; margin: 20px 0; }\n        .countdown { background: #2f3542; color: white; padding: 20px; border-radius: 10px; margin: 20px 0; }\n        .footer { background: #2f3542; color: white; padding: 20px; text-align: center; }\n    </style>\n\n\n    <div class=\"container\">\n        <div class=\"header\">\n            <div class=\"offer-badge\">LIMITED TIME OFFER</div>\n            <h1>???? MEGA SALE</h1>\n            <h2>50% OFF Everything!</h2>\n        </div>\n        <div class=\"content\">\n            <p>Hi {name},</p>\n            <p>This is your chance to get premium VPN protection at an unbeatable price!</p>\n            \n            <div class=\"price-box\">\n                <h3>Premium Annual Plan</h3>\n                <div class=\"old-price\">$99.99/year</div>\n                <div class=\"new-price\">$49.99/year</div>\n                <p><strong>Save $50 instantly!</strong></p>\n            </div>\n            \n            <div class=\"countdown\">\n                <h3>⏰ Hurry! Offer expires in:</h3>\n                <p style=\"font-size: 24px; margin: 0;\"><strong>48 HOURS</strong></p>\n            </div>\n            \n            <a href=\"{website_url}\" class=\"cta-button\">Claim Your 50% Discount</a>\n            \n            <p><strong>What you get:</strong></p>\n            <p>✅ Unlimited bandwidth<br>\n            ✅ 100+ server locations<br>\n            ✅ 24/7 customer support<br>\n            ✅ 30-day money-back guarantee</p>\n            \n            <p><em>No coupon code needed - discount applied automatically!</em></p>\n        </div>\n        <div class=\"footer\">\n            <p>This offer is exclusive to our subscribers</p>\n            <p><a href=\"{unsubscribe_url}\" style=\"color: #a4b0be;\">Unsubscribe</a></p>\n        </div>\n    </div>', 'html', 'promotion', 1, '2025-11-12 17:46:27', '2025-11-12 17:46:27', '1'),
(25, 'Welcome Email', 'Welcome to {website_name}!', '<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>body{font-family:Arial,sans-serif;margin:0;padding:20px;background:#f4f4f4}.container{max-width:600px;margin:0 auto;background:white;padding:30px;border-radius:8px}</style></head><body><div class=\"container\"><h1>Welcome {name}!</h1><p>Thank you for joining us. We are excited to have you aboard!</p><p>Best regards,<br>The Team</p></div></body></html>', 'html', 'welcome', 0, '2025-11-12 21:21:50', '2025-11-12 21:21:50', '1'),
(26, 'Newsletter Template', 'Monthly Newsletter - {website_name}', '<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>body{font-family:Arial,sans-serif;margin:0;padding:20px;background:#f4f4f4}.container{max-width:600px;margin:0 auto;background:white;padding:30px;border-radius:8px}.header{background:#007bff;color:white;padding:20px;text-align:center;border-radius:8px 8px 0 0}</style></head><body><div class=\"container\"><div class=\"header\"><h1>📰 Monthly Newsletter</h1></div><div style=\"padding:20px\"><p>Hello {name},</p><p>Here are the latest updates from our team...</p><p>Best regards,<br>The Newsletter Team</p></div></div></body></html>', 'html', 'newsletter', 0, '2025-11-12 21:21:50', '2025-11-12 21:21:50', '1'),
(27, 'Promotion Email', 'Special Offer Just for You!', '<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>body{font-family:Arial,sans-serif;margin:0;padding:20px;background:#f4f4f4}.container{max-width:600px;margin:0 auto;background:white;padding:30px;border-radius:8px}.promo{background:#28a745;color:white;padding:20px;text-align:center;border-radius:8px;margin:20px 0}</style></head><body><div class=\"container\"><h1>🎉 Special Offer!</h1><div class=\"promo\"><h2>50% OFF</h2><p>Limited time offer for {name}</p></div><p>Don\'t miss out on this amazing deal!</p><p>Best regards,<br>The Sales Team</p></div></body></html>', 'html', 'promotion', 0, '2025-11-12 21:21:50', '2025-11-12 21:21:50', '1'),
(28, 'Welcome Email', 'Welcome to {website_name}!', '<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>body{font-family:Arial,sans-serif;margin:0;padding:20px;background:#f4f4f4}.container{max-width:600px;margin:0 auto;background:white;padding:30px;border-radius:8px}</style></head><body><div class=\"container\"><h1>Welcome {name}!</h1><p>Thank you for joining us. We are excited to have you aboard!</p><p>Best regards,<br>The Team</p></div></body></html>', 'html', 'welcome', 0, '2025-11-12 22:01:16', '2025-11-12 22:01:16', '1'),
(29, 'Newsletter Template', 'Monthly Newsletter - {website_name}', '<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>body{font-family:Arial,sans-serif;margin:0;padding:20px;background:#f4f4f4}.container{max-width:600px;margin:0 auto;background:white;padding:30px;border-radius:8px}.header{background:#007bff;color:white;padding:20px;text-align:center;border-radius:8px 8px 0 0}</style></head><body><div class=\"container\"><div class=\"header\"><h1>📰 Monthly Newsletter</h1></div><div style=\"padding:20px\"><p>Hello {name},</p><p>Here are the latest updates from our team...</p><p>Best regards,<br>The Newsletter Team</p></div></div></body></html>', 'html', 'newsletter', 0, '2025-11-12 22:01:16', '2025-11-12 22:01:16', '1'),
(30, 'Promotion Email', 'Special Offer Just for You!', '<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><style>body{font-family:Arial,sans-serif;margin:0;padding:20px;background:#f4f4f4}.container{max-width:600px;margin:0 auto;background:white;padding:30px;border-radius:8px}.promo{background:#28a745;color:white;padding:20px;text-align:center;border-radius:8px;margin:20px 0}</style></head><body><div class=\"container\"><h1>🎉 Special Offer!</h1><div class=\"promo\"><h2>50% OFF</h2><p>Limited time offer for {name}</p></div><p>Don\'t miss out on this amazing deal!</p><p>Best regards,<br>The Sales Team</p></div></body></html>', 'html', 'promotion', 0, '2025-11-12 22:01:16', '2025-11-12 22:01:16', '1');

-- Table `freeze_request` --
CREATE TABLE `freeze_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(128) NOT NULL DEFAULT 'Freeze Request',
  `status` enum('pending','approved') NOT NULL DEFAULT 'pending',
  `client_id` int(11) NOT NULL,
  `client_name` varchar(128) NOT NULL,
  `client_ipaddress` varchar(128) NOT NULL DEFAULT '0.0.0.0',
  `request_date` datetime NOT NULL DEFAULT current_timestamp(),
  `reseller_id` int(11) NOT NULL,
  `reseller_name` varchar(128) NOT NULL,
  `reseller_ipaddress` varchar(128) NOT NULL DEFAULT '0.0.0.0',
  `process_date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Table `json_update` --
CREATE TABLE `json_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET latin1 NOT NULL,
  `type` int(10) NOT NULL,
  `encryption` varchar(50) CHARACTER SET latin1 NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `json_update` (`id`, `name`, `type`, `encryption`, `date`) VALUES
(96, 'ccccc', 1, '892bd88ab7afb2ad4204', '2025-12-03 16:59:25');

-- Table `limit_logs` --
CREATE TABLE `limit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `username` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `subadmin_limit` int(11) NOT NULL DEFAULT 0,
  `reseller_limit` int(11) NOT NULL DEFAULT 0,
  `subreseller_limit` int(11) NOT NULL DEFAULT 0,
  `client_limit` int(11) NOT NULL,
  `user_level` enum('normal','reseller','subreseller','subadmin','admin','superadmin') COLLATE latin1_general_ci NOT NULL DEFAULT 'normal',
  `logs_date` datetime NOT NULL,
  `ipaddress` varchar(64) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Table `limit_registration` --
CREATE TABLE `limit_registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `regtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `login_attempts` --
CREATE TABLE `login_attempts` (
  `ip` varchar(20) DEFAULT NULL,
  `attempts` int(11) DEFAULT 0,
  `lastlogin` datetime DEFAULT NULL,
  `timestamp` int(11) NOT NULL,
  KEY `idx_ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `login_attempts_logs` --
CREATE TABLE `login_attempts_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) DEFAULT NULL,
  `user_name` varchar(64) NOT NULL,
  `logs_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=321 DEFAULT CHARSET=latin1;

-- Table `login_banned_ip` --
CREATE TABLE `login_banned_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `ip` varchar(128) NOT NULL DEFAULT '0.0.0.0',
  `logs_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=196 DEFAULT CHARSET=latin1;

-- Table `nas` --
CREATE TABLE `nas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nasname` varchar(128) NOT NULL,
  `shortname` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT 'other',
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) NOT NULL DEFAULT 'secret',
  `server` varchar(64) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT 'RADIUS Client',
  PRIMARY KEY (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Table `notification` --
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET latin1 NOT NULL,
  `filename` varchar(50) CHARACTER SET latin1 NOT NULL,
  `type` int(10) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `page_content` --
CREATE TABLE `page_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(100) NOT NULL,
  `section_name` varchar(100) NOT NULL,
  `section_content` text NOT NULL,
  `section_type` enum('text','textarea','html') DEFAULT 'text',
  `is_active` tinyint(1) DEFAULT 1,
  `section_order` int(11) DEFAULT 1,
  `created_date` datetime DEFAULT current_timestamp(),
  `updated_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_page_name` (`page_name`),
  KEY `idx_section_order` (`section_order`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;

INSERT INTO `page_content` (`id`, `page_name`, `section_name`, `section_content`, `section_type`, `is_active`, `section_order`, `created_date`, `updated_date`) VALUES
(1, 'site-info', 'hero_title', 'Saudi Arabia SIM Companie', 'text', '1', 1, '2025-11-13 15:38:58', '2025-11-13 15:38:58'),
(2, 'site-info', 'main_description', '<font color=\"#ff0000\">Choose from premium telecom services offering high-speed internet, unlimited calls, and exclusive packages. Compare</font> <span style=\"color: #28a745; font-weight: bold;\">FREE plans</span> and <span style=\"color: #007bff; font-weight: bold;\">PREMIUM packages</span> <font color=\"#9c00ff\">from leading operators across the Kingdom.</font>', 'text', '1', 1, '2025-11-13 15:38:58', '2025-11-13 16:25:06'),
(3, 'site-info', 'stc_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:40'),
(4, 'site-info', 'stc_package_title', 'Stc Plan', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(5, 'site-info', 'stc_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(6, 'site-info', 'stc_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(7, 'site-info', 'mobily_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(8, 'site-info', 'mobily_package_title', 'Mobily Plan', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(9, 'site-info', 'mobily_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(10, 'site-info', 'mobily_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(11, 'site-info', 'zain_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(12, 'site-info', 'zain_package_title', 'Zain Plan', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(13, 'site-info', 'zain_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(14, 'site-info', 'zain_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(15, 'site-info', 'virgin_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(16, 'site-info', 'virgin_package_title', 'Virgin Plan', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(17, 'site-info', 'virgin_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(18, 'site-info', 'virgin_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(19, 'site-info', 'lebara_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(20, 'site-info', 'lebara_package_title', 'Lebara Plan', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(21, 'site-info', 'lebara_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:49', '2025-11-13 16:57:41'),
(22, 'site-info', 'lebara_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:41'),
(23, 'site-info', 'friendi_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:41'),
(24, 'site-info', 'friendi_package_title', 'Friendi Plan', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:41'),
(25, 'site-info', 'friendi_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:41'),
(26, 'site-info', 'friendi_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:41'),
(27, 'site-info', 'redbull_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:41'),
(28, 'site-info', 'redbull_package_title', 'Redbull Plan', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(29, 'site-info', 'redbull_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(30, 'site-info', 'redbull_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(31, 'site-info', 'salam_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(32, 'site-info', 'salam_package_title', 'Salam Plan', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(33, 'site-info', 'salam_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(34, 'site-info', 'salam_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(35, 'site-info', 'jawwy_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(36, 'site-info', 'jawwy_package_title', 'Jawwy Plan', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(37, 'site-info', 'jawwy_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(38, 'site-info', 'jawwy_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(39, 'site-info', 'yaqoot_package_type', 'FREE', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(40, 'site-info', 'yaqoot_package_title', 'Yaqoot Plan', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(41, 'site-info', 'yaqoot_package_description', 'Package description', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42'),
(42, 'site-info', 'yaqoot_package_features', 'Package features', 'text', '1', 1, '2025-11-13 16:30:50', '2025-11-13 16:57:42');

-- Table `page_customizations` --
CREATE TABLE `page_customizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(100) NOT NULL,
  `customization_type` varchar(50) NOT NULL,
  `customization_data` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `updated_date` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_page_customization` (`page_name`,`customization_type`),
  KEY `idx_page_name` (`page_name`),
  KEY `idx_customization_type` (`customization_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `page_customizations` (`id`, `page_name`, `customization_type`, `customization_data`, `user_id`, `created_date`, `updated_date`) VALUES
(1, 'site-info', 'design', '{\"colorScheme\":\"blue\",\"fontFamily\":\"nunito, \\\"segoe ui\\\", arial\",\"fontSize\":\"14\",\"cardOpacity\":\"1\",\"animationSpeed\":\"3\"}', 1, '2025-11-13 15:39:22', '2025-11-13 17:52:43'),
(2, 'site-info', 'layout', '{\"layoutType\":\"grid\",\"cardSpacing\":\"20\",\"containerWidth\":\"100\"}', 1, '2025-11-13 15:40:43', '2025-11-13 17:52:43');

-- Table `radacct` --
CREATE TABLE `radacct` (
  `radacctid` bigint(21) NOT NULL AUTO_INCREMENT,
  `acctsessionid` varchar(64) NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `realm` varchar(64) DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasportid` varchar(15) DEFAULT NULL,
  `nasporttype` varchar(32) DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctsessiontime` int(12) unsigned DEFAULT NULL,
  `acctauthentic` varchar(32) DEFAULT NULL,
  `connectinfo_start` varchar(50) DEFAULT NULL,
  `connectinfo_stop` varchar(50) DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) NOT NULL DEFAULT '',
  `callingstationid` varchar(50) NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) NOT NULL DEFAULT '',
  `servicetype` varchar(32) DEFAULT NULL,
  `framedprotocol` varchar(32) DEFAULT NULL,
  `framedipaddress` varchar(15) NOT NULL DEFAULT '',
  `acctstartdelay` int(12) unsigned DEFAULT NULL,
  `acctstopdelay` int(12) unsigned DEFAULT NULL,
  `xascendsessionsvrkey` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`radacctid`),
  UNIQUE KEY `acctuniqueid` (`acctuniqueid`),
  KEY `username` (`username`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `acctsessionid` (`acctsessionid`),
  KEY `acctsessiontime` (`acctsessiontime`),
  KEY `acctstarttime` (`acctstarttime`),
  KEY `acctstoptime` (`acctstoptime`),
  KEY `nasipaddress` (`nasipaddress`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table `radcheck` --
CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `radcheck` (`id`, `username`, `attribute`, `op`, `value`) VALUES
(4, '28870', 'Cleartext-Password', ':=', '68544'),
(5, '23341', 'Cleartext-Password', ':=', '765666'),
(6, '87069', 'Cleartext-Password', ':=', '64969'),
(7, '63646', 'Cleartext-Password', ':=', '40742'),
(11, '15423', 'Cleartext-Password', ':=', '68132'),
(12, '214352', 'Cleartext-Password', ':=', '02025'),
(13, '30480', 'Cleartext-Password', ':=', '29657'),
(14, '73571', 'Cleartext-Password', ':=', '28462'),
(15, '54718', 'Cleartext-Password', ':=', '16071'),
(16, '66743', 'Cleartext-Password', ':=', '32323');

-- Table `radgroupcheck` --
CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `radgroupreply` --
CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `radpostauth` --
CREATE TABLE `radpostauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `pass` varchar(64) NOT NULL DEFAULT '',
  `reply` varchar(32) NOT NULL DEFAULT '',
  `authdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table `radreply` --
CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `radusergroup` --
CREATE TABLE `radusergroup` (
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `priority` int(11) NOT NULL DEFAULT 1,
  KEY `username` (`username`(32))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `recovery_logs` --
CREATE TABLE `recovery_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recovery_menu` varchar(255) NOT NULL,
  `recovery_ipaddress` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `recovery_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Table `reloadduration_logs` --
CREATE TABLE `reloadduration_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `duration_id` int(11) NOT NULL,
  `duration_id2` int(11) NOT NULL,
  `duration_username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duration_item` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duration_date` datetime NOT NULL,
  `duration_type` enum('premium','vip','private') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'premium',
  `ipaddress` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `reseller_applications` --
CREATE TABLE `reseller_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `experience` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `expected_sales` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected','under_review') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `admin_notes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `applied_date` datetime NOT NULL DEFAULT current_timestamp(),
  `reviewed_date` datetime DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  KEY `status` (`status`),
  KEY `applied_date` (`applied_date`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `reseller_applications` (`id`, `business_name`, `full_name`, `email`, `username`, `password`, `phone`, `country`, `website`, `experience`, `expected_sales`, `message`, `status`, `admin_notes`, `applied_date`, `reviewed_date`, `reviewed_by`, `ip_address`, `user_agent`) VALUES
(5, 'azimxxx', 'Anoarul Azimxxx', 'ghadeeralemaarcse@gmail.com', 'azimkawsar', '$2y$10$qcwnzlvOiCHDinO8tJO5Qua8Rm0fvFF0WDm6ehSrd21e6uZTz99mO', '0598126772', 'SA', 'https://mancaberone.com', 'intermediate', '51-100', 'cccccccccccc', 'approved', 'Approved and reseller account created (Username: azimkawsar)', '2025-11-14 17:37:37', '2025-11-14 17:38:59', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'),
(6, 'azim', 'Anoarul Azim', 'ghadeeralemaarce@gmail.com', 'reseller4', '$2y$10$Dprkvn1KWEpZs40TzcPL.OwFXhFJfMPKP9gdbn7/nAvMLKx0EgpS.', '0598126771', 'SA', 'Voillom.com', 'intermediate', '51-100', 'xxxx', 'approved', 'Approved and reseller account created (Username: reseller4)', '2025-11-14 17:38:34', '2025-11-14 17:40:11', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36');

-- Table `reseller_settings` --
CREATE TABLE `reseller_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8_unicode_ci NOT NULL,
  `updated_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_name` (`setting_name`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `reseller_settings` (`id`, `setting_name`, `setting_value`, `updated_date`) VALUES
(1, 'email_notifications', '1', '2025-11-14 14:02:28'),
(2, 'auto_approval', '0', '2025-11-14 14:02:28'),
(3, 'admin_email', 'vollamltd@gmail.com', '2025-11-14 17:36:06'),
(4, 'welcome_email_subject', 'Welcome to Our Reseller Program', '2025-11-14 14:02:28'),
(5, 'welcome_email_body', '<p>Dear {name},</p><p>Welcome to our reseller program! Your application has been approved.</p><p><strong>Your reseller account details:</strong><br>Username: {username}<br>Password: {password}<br>Reseller Panel: {reseller_url}</p><p style=\"font-family: &quot;Hind Siliguri&quot;, Arial, sans-serif; line-height: 1.7;\" class=\"bangla-text\">আপনাকে স্বাগতম! আপনার রিসেলার আবেদন অনুমোদিত হয়েছে।</p><p>Best regards,<br>The Team</p>', '2025-11-14 14:02:29'),
(6, 'approval_email_subject', 'Reseller Application Approved', '2025-11-14 14:02:29'),
(7, 'approval_email_body', '<p>Dear {name},</p><p>Congratulations! Your reseller application for <strong>{business_name}</strong> has been approved.</p><p style=\"font-family: &quot;Hind Siliguri&quot;, Arial, sans-serif; line-height: 1.7;\" class=\"bangla-text\">অভিনন্দন! আপনার রিসেলার আবেদন অনুমোদিত হয়েছে।</p><p>We will contact you shortly with your account details.</p><p>Best regards,<br>The Team</p>', '2025-11-14 14:02:29'),
(8, 'rejection_email_subject', 'Reseller Application Update', '2025-11-14 14:02:29'),
(9, 'rejection_email_body', '<p>Dear {name},</p><p>Thank you for your interest in our reseller program.</p><p>After careful review, we are unable to approve your application at this time.</p><p><strong>Reason:</strong> {reason}</p><p style=\"font-family: &quot;Hind Siliguri&quot;, Arial, sans-serif; line-height: 1.7;\" class=\"bangla-text\">দুঃখিত, আপনার আবেদন এই মুহূর্তে অনুমোদন করা সম্ভব হয়নি।</p><p>You may reapply in the future.</p><p>Best regards,<br>The Team</p>', '2025-11-14 14:02:29'),
(10, 'smtp_enabled', '1', '2025-11-14 14:02:28'),
(11, 'smtp_host', 'smtp.gmail.com', '2025-11-14 14:02:28'),
(12, 'smtp_port', '587', '2025-11-14 14:02:28'),
(13, 'smtp_security', 'tls', '2025-11-14 14:02:28'),
(14, 'smtp_username', 'datasoftcaresales@gmail.com', '2025-11-14 14:02:28'),
(15, 'smtp_password', 'ffhgafnyzwyinujy', '2025-11-14 14:02:28'),
(16, 'smtp_from_email', 'datasoftcaresales@gmail.com', '2025-11-14 14:02:28'),
(17, 'smtp_from_name', 'VPN Panel', '2025-11-14 14:02:28'),
(27, 'gmail_username', 'datasoftcaresales@gmail.com', '2025-11-14 14:02:28'),
(26, 'gmail_enabled', '0', '2025-11-14 14:02:28'),
(18, 'bulk_email_enabled', '1', '2025-11-12 14:37:43'),
(19, 'bulk_email_per_batch', '50', '2025-11-12 14:37:43'),
(20, 'bulk_email_delay', '5', '2025-11-12 14:37:43'),
(21, 'bulk_email_from_name', 'VPN Panel', '2025-11-12 14:37:43'),
(22, 'bulk_email_reply_to', '', '2025-11-12 14:37:43'),
(23, 'email_tracking_enabled', '1', '2025-11-12 14:37:43'),
(24, 'email_unsubscribe_enabled', '1', '2025-11-12 14:37:43'),
(25, 'smtp_type', 'gmail', '2025-11-14 14:02:28'),
(28, 'gmail_from_name', 'VPN Panel System', '2025-11-14 14:02:28'),
(29, 'webmail_host', 'mail.ruzain.com', '2025-11-14 14:02:28'),
(30, 'webmail_port', '587', '2025-11-14 14:02:28'),
(31, 'webmail_security', 'tls', '2025-11-14 14:02:28'),
(32, 'webmail_username', 'info@ruzain.com', '2025-11-14 14:02:28'),
(33, 'webmail_password', '', '2025-11-14 14:02:28'),
(34, 'webmail_from_name', 'VPN Panel', '2025-11-14 14:02:28');

-- Table `server_list` --
CREATE TABLE `server_list` (
  `server_id` int(255) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(255) NOT NULL,
  `server_ip` varchar(20) NOT NULL,
  `server_user` varchar(50) NOT NULL,
  `server_pass` varchar(255) NOT NULL,
  `flag` varchar(10) NOT NULL,
  `a_id` varchar(55) NOT NULL,
  `ns_id` varchar(55) NOT NULL,
  `auth_str` varchar(55) NOT NULL,
  `port_tcp` int(11) NOT NULL,
  `port_udp` int(11) NOT NULL,
  `port_ssh` int(11) NOT NULL,
  `hysteria_port` int(11) NOT NULL,
  `xray_port` int(11) NOT NULL,
  `socksip_port` varchar(11) NOT NULL,
  `xray_tls` int(11) NOT NULL,
  `xray_ntls` int(11) NOT NULL,
  `slowdns_port` int(11) NOT NULL,
  `ssh_port` int(11) NOT NULL,
  `dropbear_port` int(11) NOT NULL,
  `protocol` int(11) NOT NULL,
  `online` int(11) NOT NULL,
  `hysteria_online` int(11) NOT NULL,
  `ssh_online` int(11) NOT NULL,
  `cpu_model` varchar(55) NOT NULL,
  `distro` varchar(55) NOT NULL,
  `memory` varchar(50) NOT NULL,
  `uptime` varchar(30) NOT NULL,
  `disk` varchar(30) NOT NULL,
  `bandwidth` varchar(50) NOT NULL,
  `os` varchar(25) NOT NULL,
  `proto` varchar(30) NOT NULL,
  `tcpssl` varchar(25) NOT NULL,
  `udpssl` varchar(25) NOT NULL,
  `tcp_status` varchar(10) NOT NULL,
  `udp_status` varchar(10) NOT NULL,
  `ssl_status` varchar(10) NOT NULL,
  `squid_status` varchar(10) NOT NULL,
  `socket_status` varchar(10) NOT NULL,
  `hysteria_status` varchar(10) NOT NULL,
  `xray_status` varchar(10) NOT NULL,
  `slowdns_status` varchar(10) NOT NULL,
  `ssh_status` varchar(10) NOT NULL,
  `dropbear_status` varchar(10) NOT NULL,
  `socksip_status` varchar(11) NOT NULL,
  `xray_vmess` varchar(11) NOT NULL,
  `xray_vless` varchar(11) NOT NULL,
  `xray_trojan` varchar(11) NOT NULL,
  `xray_ss` varchar(11) NOT NULL,
  `tcp` varchar(25) NOT NULL,
  `udp` varchar(25) NOT NULL,
  `squid` varchar(25) NOT NULL,
  `socket` varchar(25) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`server_id`),
  KEY `idx_server_ip` (`server_ip`),
  KEY `idx_proto` (`proto`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `server_list` (`server_id`, `server_name`, `server_ip`, `server_user`, `server_pass`, `flag`, `a_id`, `ns_id`, `auth_str`, `port_tcp`, `port_udp`, `port_ssh`, `hysteria_port`, `xray_port`, `socksip_port`, `xray_tls`, `xray_ntls`, `slowdns_port`, `ssh_port`, `dropbear_port`, `protocol`, `online`, `hysteria_online`, `ssh_online`, `cpu_model`, `distro`, `memory`, `uptime`, `disk`, `bandwidth`, `os`, `proto`, `tcpssl`, `udpssl`, `tcp_status`, `udp_status`, `ssl_status`, `squid_status`, `socket_status`, `hysteria_status`, `xray_status`, `slowdns_status`, `ssh_status`, `dropbear_status`, `socksip_status`, `xray_vmess`, `xray_vless`, `xray_trojan`, `xray_ss`, `tcp`, `udp`, `squid`, `socket`, `status`) VALUES
(1, 'Server', '172.236.192.120', 'root', 'azim.0987Aa', 'DE', '', '', 'None', 1194, 110, 22, 5666, 0, '', 0, 0, 0, 0, 0, 11, 0, 0, 0, 'AMD EPYC 7713 @ 2.000GHz ', 'Debian GNU/Linux 12 (bookworm) x86_64 ', '192MiB / 3915MiB ', '5 hours, 12 mins ', '2.3G / 79G (4%) ', '594.29 MiB', 'Linux ', 'openvpn', '443', '444', 'active', 'active', 'active', 'active', 'active', 'active', '', '', '', '', '', '', '', '', '', '1194', '110', '8080', '80', 1);

-- Table `site_options` --
CREATE TABLE `site_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(155) NOT NULL,
  `logo` varchar(155) NOT NULL,
  `logo_status` int(10) NOT NULL,
  `maintenance_status` int(10) NOT NULL,
  `prefix_status` int(11) NOT NULL,
  `prefix` varchar(50) NOT NULL,
  `trial_duration` int(25) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `theme` varchar(50) NOT NULL,
  `login_note` varchar(256) NOT NULL,
  `session_limit` int(10) NOT NULL,
  `dns_prefix` varchar(155) NOT NULL,
  `dns_domain` varchar(155) NOT NULL,
  `dns_global` varchar(155) NOT NULL,
  `dns_zone` varchar(155) NOT NULL,
  `dns_email` varchar(155) NOT NULL,
  `site_status` int(11) NOT NULL,
  `github_username` varchar(155) NOT NULL,
  `github_token` varchar(155) NOT NULL,
  `github_repo` varchar(255) DEFAULT NULL,
  `update_json` varchar(155) NOT NULL,
  `license` varchar(155) NOT NULL,
  `bak_to` varchar(155) NOT NULL,
  `bak_cc` varchar(155) NOT NULL,
  `otp_code` varchar(11) NOT NULL,
  `otp_id` varchar(11) NOT NULL,
  `otp_duration` int(11) NOT NULL,
  `otp_rsnd` varchar(50) NOT NULL,
  `turnstile_key` varchar(55) NOT NULL,
  `turnstile_secret` varchar(55) NOT NULL,
  `hits` int(11) NOT NULL,
  `whois_api` varchar(50) NOT NULL,
  `bandwidth_limit` int(11) DEFAULT 0,
  `xray_limit` varchar(20) DEFAULT 'disabled',
  `bandwidth_value` decimal(10,2) DEFAULT 0.00,
  `bandwidth_unit` varchar(10) DEFAULT 'gb',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `site_options` (`id`, `email`, `name`, `description`, `logo`, `logo_status`, `maintenance_status`, `prefix_status`, `prefix`, `trial_duration`, `owner`, `theme`, `login_note`, `session_limit`, `dns_prefix`, `dns_domain`, `dns_global`, `dns_zone`, `dns_email`, `site_status`, `github_username`, `github_token`, `github_repo`, `update_json`, `license`, `bak_to`, `bak_cc`, `otp_code`, `otp_id`, `otp_duration`, `otp_rsnd`, `turnstile_key`, `turnstile_secret`, `hits`, `whois_api`, `bandwidth_limit`, `xray_limit`, `bandwidth_value`, `bandwidth_unit`) VALUES
(1, 'azimaxus@gmail.com', 'Vollam', 'Fast and Secure', '1763767623.png', 1, 0, 0, 'vip', 7200, 'Vollam', 'purple', 'cW5vRi8vU1hsYVk0Um1vdXo3MTlmQT09', 99999, '', 'jaeAZs3OqOTM09ualc+kj6ultIa4wmvhf4aE54W1nJM=', 'j7urnNi7sbfbq9eRfqjJeKSp1pa8w5Whh6umpou4z46dyZ6tipR4jazTfuizupnJgt2Uk4a8vKq6oKSizcCAq9K/dp60ud3puomIrqy6u9yGvLq+zaeqkw==', 'kNG/Z9qqtdzL0r2Yfs6PoJeW2qe5wIy6fIeZ5ZWo5MS3louDhruDeK6Mha2sqbvBfN16w4Wswaq5sMKgv6iWssODisWekr+lu8Gcw66ToJ2Jo5jHw82qkw==', 'is27ftm5k9vJqcR2hJHFdp6DvIa+nZq2f5p07YbMuYurybCnlqamiZjGgqyoqLvDk8+gf5a5z4Gnroat', 1, 'azimaxas', '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', 'ruzain.com', 'https://ruzain.com', 'KEY-466C39F3-FCD6E57B', 'azimaxus@gmail.com', 'azimaxus@gmail.com', '', '', 0, '', '0x4AAAAAAB12VfPkRndAiEbc', '0x4AAAAAAB12VR34JJpaXjqrHy5D8f0FA0A', 400, 'F8PVAPHDTFSHEhHHJmH06uyJX5lQYtxB', 2147483647, 'disabled', '90.00', 'gb');

-- Table `slider_images` --
CREATE TABLE `slider_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image_url` varchar(255) NOT NULL,
  `link_url` varchar(500) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 1,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `slider_images` (`id`, `title`, `description`, `image_url`, `link_url`, `sort_order`, `status`, `created_at`, `updated_at`) VALUES
(1, '50% offer', 'Reseller Get this offer', 'slider_1765056736_6934a0e08c715.jpg', 'https://ruzain.com', 1, 'active', '2025-12-07 00:08:22', '2025-12-07 00:32:16'),
(3, 'Best Speed Server', '100+ Server', 'slider_1765056833_6934a141d9c6d.jpg', 'https://ruzain.com', 3, 'active', '2025-12-07 00:24:31', '2025-12-07 00:33:53'),
(4, 'Premium VPN', 'High Speed VPN', 'slider_1765056790_6934a116cfdb5.jpg', 'https://ruzain.com', 2, 'active', '2025-12-07 00:28:39', '2025-12-07 00:33:10');

-- Table `subscriber_config` --
CREATE TABLE `subscriber_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(11) NOT NULL,
  `email_frequency` enum('daily','weekly','monthly','never') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'weekly',
  `email_format` enum('html','text') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'html',
  `marketing_emails` tinyint(1) NOT NULL DEFAULT 1,
  `newsletter` tinyint(1) NOT NULL DEFAULT 1,
  `product_updates` tinyint(1) NOT NULL DEFAULT 1,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscriber_id` (`subscriber_id`),
  KEY `email_frequency` (`email_frequency`),
  KEY `email_format` (`email_format`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Table `support_message` --
CREATE TABLE `support_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `support_message` text NOT NULL,
  `support_id_user` int(11) NOT NULL,
  `support_name` varchar(767) NOT NULL,
  `support_groupname` varchar(767) NOT NULL,
  `support_date` datetime NOT NULL,
  `support_ipaddress` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table `support_ticket` --
CREATE TABLE `support_ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_name` varchar(767) NOT NULL,
  `ticket_subject` varchar(767) NOT NULL,
  `ticket_message` text NOT NULL,
  `ticket_status` enum('open','customer-reply','answered','closed') NOT NULL,
  `ticket_date` datetime NOT NULL,
  `ticket_update` datetime NOT NULL,
  `ip_address` varchar(767) NOT NULL,
  `ticket_id_user` int(11) NOT NULL,
  `ticket_groupname` varchar(767) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table `suspension_logs` --
CREATE TABLE `suspension_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_suspended` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `client_username` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `offense` varchar(225) NOT NULL,
  `logs_date` datetime NOT NULL,
  `ipaddress` varchar(32) NOT NULL DEFAULT '0.0.0.0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Table `suspension_recovery_logs` --
CREATE TABLE `suspension_recovery_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `client_username` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `suspend_date` datetime NOT NULL,
  `offense` varchar(225) NOT NULL,
  `logs_date` datetime NOT NULL,
  `is_unsuspended` int(11) NOT NULL,
  `ipaddress` varchar(32) NOT NULL DEFAULT '0.0.0.0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Table `username_logs` --
CREATE TABLE `username_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `old_username` varchar(50) NOT NULL,
  `new_username` varchar(50) NOT NULL,
  `old_level` varchar(64) NOT NULL,
  `new_level` varchar(64) NOT NULL,
  `old_upline` int(11) NOT NULL,
  `new_upline` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `logs_date` datetime NOT NULL,
  `ipaddress` varchar(32) NOT NULL DEFAULT '0.0.0.0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1061 DEFAULT CHARSET=latin1;

-- Table `users` --
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(50) NOT NULL DEFAULT 'jho',
  `code` varchar(10) NOT NULL,
  `ss_id` varchar(64) NOT NULL,
  `ssl_id` varchar(50) NOT NULL DEFAULT 'ssl',
  `username_prefix` varchar(11) NOT NULL,
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `user_pass` varchar(256) NOT NULL,
  `user_2fa` int(11) NOT NULL,
  `user_2fa_otp` varchar(11) NOT NULL,
  `user_2fa_id` varchar(11) NOT NULL,
  `user_2fa_duration` int(11) NOT NULL,
  `attribute` varchar(64) NOT NULL DEFAULT 'MD5-Password',
  `op` char(2) NOT NULL DEFAULT ':=',
  `auth_vpn` varchar(256) NOT NULL,
  `user_email` varchar(50) NOT NULL DEFAULT '',
  `user_email_verified` int(11) NOT NULL,
  `full_name` varchar(50) DEFAULT NULL,
  `regdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddress` varchar(50) NOT NULL DEFAULT '0.0.0.0',
  `lastlogin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `timestamp` int(11) NOT NULL,
  `reset_code` varchar(255) NOT NULL DEFAULT '0',
  `is_groupname` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_freeze` tinyint(1) NOT NULL DEFAULT 1,
  `is_passchange` int(11) NOT NULL,
  `passchange_duration` int(25) NOT NULL,
  `last_freeze_date` datetime NOT NULL,
  `is_validated` tinyint(1) NOT NULL DEFAULT 0,
  `is_connected` int(1) NOT NULL DEFAULT 0,
  `is_offense` int(11) NOT NULL DEFAULT 0,
  `is_ban` int(11) NOT NULL DEFAULT 1,
  `is_socksip` int(11) NOT NULL,
  `user_group` int(100) NOT NULL,
  `suspended_date` datetime NOT NULL,
  `duration` bigint(50) NOT NULL DEFAULT 18000,
  `vip_duration` bigint(50) NOT NULL,
  `is_vip` int(11) NOT NULL DEFAULT 0,
  `private_duration` bigint(50) NOT NULL DEFAULT 0,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `private_slot` int(11) NOT NULL DEFAULT 0,
  `private_control` tinyint(1) NOT NULL DEFAULT 0,
  `credits` int(20) NOT NULL DEFAULT 0,
  `upline` int(10) NOT NULL DEFAULT 1,
  `login_status` enum('offline','online') NOT NULL DEFAULT 'offline',
  `last_active_time` datetime NOT NULL,
  `user_level` enum('normal','subreseller','reseller','administrator','subadmin','superadmin','bulk','trial','developer') NOT NULL,
  `status` enum('live','freeze','suspended','banned','vacation') NOT NULL DEFAULT 'live',
  `bytes_received` int(55) NOT NULL,
  `bytes_sent` int(55) NOT NULL,
  `bandwidth` int(11) NOT NULL DEFAULT 0,
  `bandwidth_premium` int(11) NOT NULL,
  `bandwidth_vip` int(11) NOT NULL,
  `bandwidth_ph` int(11) NOT NULL,
  `bandwidth_private` int(11) NOT NULL,
  `bandwidth_free` int(11) NOT NULL,
  `device_connected` int(2) NOT NULL DEFAULT 0,
  `device_id` varchar(100) NOT NULL,
  `device_model` varchar(100) NOT NULL,
  `session` int(50) NOT NULL,
  `active_address` varchar(25) NOT NULL,
  `active_date` datetime NOT NULL,
  `bandwidth_used` bigint(20) unsigned DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=57753 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `password`, `code`, `ss_id`, `ssl_id`, `username_prefix`, `user_name`, `user_pass`, `user_2fa`, `user_2fa_otp`, `user_2fa_id`, `user_2fa_duration`, `attribute`, `op`, `auth_vpn`, `user_email`, `user_email_verified`, `full_name`, `regdate`, `ipaddress`, `lastlogin`, `timestamp`, `reset_code`, `is_groupname`, `is_active`, `is_freeze`, `is_passchange`, `passchange_duration`, `last_freeze_date`, `is_validated`, `is_connected`, `is_offense`, `is_ban`, `is_socksip`, `user_group`, `suspended_date`, `duration`, `vip_duration`, `is_vip`, `private_duration`, `is_private`, `private_slot`, `private_control`, `credits`, `upline`, `login_status`, `last_active_time`, `user_level`, `status`, `bytes_received`, `bytes_sent`, `bandwidth`, `bandwidth_premium`, `bandwidth_vip`, `bandwidth_ph`, `bandwidth_private`, `bandwidth_free`, `device_connected`, `device_id`, `device_model`, `session`, `active_address`, `active_date`, `bandwidth_used`) VALUES
(1, 'hjhj', '405154310', '54090', 'any', '', 'admin', 'akU0ZW4zeU41S0tSKzVQODkrVUxSdz09', 0, 'LKRCAP0YN', 'SCK24IB6C', 600, 'MD5-Password', ':=', '0192023a7bbd73250516f069df18b500', 'admin@localhost.com', 0, 'VPN Philippines', '2018-07-09 10:59:14', '::1', '2025-12-07 17:40:31', 0, '0', 'superadmin', '0', '0', 0, 0, '0000-00-00 00:00:00', '1', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 33696000, 1305000, 1, 1728000, '1', 0, '0', 1000, 1, 'online', '2025-12-07 17:40:31', 'superadmin', 'live', 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, '', '0000-00-00 00:00:00', 0),
(57750, 'jho', '406568010', '', 'ssl', '', 'reseller', 'd25SMElzWGN0VjRhZHc1b3htNGxYUT09', 0, '', '', 0, 'MD5-Password', ':=', '9efc4ac970619de711752d818c29884a', 'reseller@email.com', 0, 'Reseller User', '2025-12-07 04:16:44', '::1', '2025-12-07 16:16:54', 0, '0', 'reseller', '1', '0', 0, 0, '0000-00-00 00:00:00', '1', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '0', 0, '0', 1, 1, 'offline', '2025-12-07 16:16:54', 'reseller', 'live', 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, '', '0000-00-00 00:00:00', 0),
(2, 'hjhj', '405154310', '54090', 'any', '', 'developer', 'akU0ZW4zeU41S0tSKzVQODkrVUxSdz09', 0, '', '', 0, 'MD5-Password', ':=', '0192023a7bbd73250516f069df18b500', 'azimaxus@gmail.com', 0, 'Vollam Developer', '2018-07-09 10:59:14', '::1', '2025-12-07 17:45:46', 0, '0', 'developer', '0', '0', 0, 0, '0000-00-00 00:00:00', '1', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 999999, 1305000, 1, 1728000, '1', 0, '0', 1000, 1, 'online', '2025-12-07 17:45:46', 'developer', 'live', 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, '', '0000-00-00 00:00:00', 0),
(57751, 'jho', '236177363', '', 'ssl', '', '66743', 'MTVteExlQkdrbjB5eStuL09ZVDhEdz09', 0, '', '', 0, 'MD5-Password', ':=', '5f6eb0809f31e88067e51bfd2bb0c50e', '66743gmail.com', 0, 'Normal User', '2025-12-07 04:36:51', '0.0.0.0', '0000-00-00 00:00:00', 0, '0', 'normal', '0', '0', 1, 240, '0000-00-00 00:00:00', '1', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 2592000, 0, 0, 0, '0', 0, '0', 0, 1, 'offline', '0000-00-00 00:00:00', 'normal', 'live', 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, '', '0000-00-00 00:00:00', 0),
(57752, 'jho', '914834136', '', 'ssl', '', 'reseller4', 'T0hMeXdyY2ZSNEVaYnFQMmdzT0g1Zz09', 0, '', '', 0, 'MD5-Password', ':=', 'a14924931c754b304a39fdcab42ce806', 'reseller4@email.com', 0, 'Reseller User', '2025-12-07 04:37:25', '0.0.0.0', '0000-00-00 00:00:00', 0, '0', 'reseller', '1', '0', 0, 0, '0000-00-00 00:00:00', '1', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '0', 0, '0', 1, 1, 'offline', '0000-00-00 00:00:00', 'reseller', 'live', 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, '', '0000-00-00 00:00:00', 0);

-- Table `users_delete` --
CREATE TABLE `users_delete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delete_timestamp` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `user_pass` varchar(256) NOT NULL,
  `auth_vpn` varchar(256) NOT NULL,
  `user_email` varchar(50) NOT NULL DEFAULT '',
  `full_name` varchar(50) DEFAULT NULL,
  `regdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddress` varchar(50) NOT NULL DEFAULT '0.0.0.0',
  `lastlogin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `timestamp` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `reset_code` varchar(255) NOT NULL DEFAULT '0',
  `is_groupname` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_freeze` tinyint(1) NOT NULL DEFAULT 1,
  `last_freeze_date` date NOT NULL,
  `is_validated` tinyint(1) NOT NULL DEFAULT 0,
  `is_connected` int(1) NOT NULL DEFAULT 0,
  `is_offense` int(11) NOT NULL DEFAULT 0,
  `is_ban` int(11) NOT NULL DEFAULT 1,
  `suspended_date` datetime NOT NULL,
  `duration` bigint(50) NOT NULL DEFAULT 7200,
  `vip_duration` bigint(50) NOT NULL,
  `is_vip` int(11) NOT NULL DEFAULT 0,
  `private_duration` bigint(50) NOT NULL DEFAULT 0,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `private_slot` int(11) NOT NULL DEFAULT 0,
  `private_control` tinyint(1) NOT NULL DEFAULT 0,
  `credits` int(20) NOT NULL DEFAULT 0,
  `upline` int(10) NOT NULL DEFAULT 1,
  `login_status` enum('offline','online') NOT NULL DEFAULT 'offline',
  `last_active_time` datetime NOT NULL,
  `user_level` enum('normal','subreseller','reseller','moderator','subadmin','superadmin','bulk','trial') NOT NULL,
  `status` enum('live','freeze','suspended','banned','vacation') NOT NULL DEFAULT 'live',
  `bandwidth` int(11) NOT NULL DEFAULT 0,
  `bandwidth_premium` int(11) NOT NULL,
  `bandwidth_vip` int(11) NOT NULL,
  `bandwidth_ph` int(11) NOT NULL,
  `bandwidth_private` int(11) NOT NULL,
  `bandwidth_free` int(11) NOT NULL,
  `device_connected` int(2) NOT NULL DEFAULT 0,
  `device_id` varchar(100) NOT NULL,
  `device_model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8890 DEFAULT CHARSET=latin1;

INSERT INTO `users_delete` (`id`, `delete_timestamp`, `user_id`, `user_name`, `user_pass`, `auth_vpn`, `user_email`, `full_name`, `regdate`, `ipaddress`, `lastlogin`, `timestamp`, `code`, `reset_code`, `is_groupname`, `is_active`, `is_freeze`, `last_freeze_date`, `is_validated`, `is_connected`, `is_offense`, `is_ban`, `suspended_date`, `duration`, `vip_duration`, `is_vip`, `private_duration`, `is_private`, `private_slot`, `private_control`, `credits`, `upline`, `login_status`, `last_active_time`, `user_level`, `status`, `bandwidth`, `bandwidth_premium`, `bandwidth_vip`, `bandwidth_ph`, `bandwidth_private`, `bandwidth_free`, `device_connected`, `device_id`, `device_model`) VALUES
(8885, 1766650413, 57739, '10314', 'ODNIZXRwZUgvc2p0ZDFqREthSUwrdz09', '72d730cd771f0c34057130547a221709', '10314gmail.com', 'Normal User', '2025-11-25 11:12:03', '0.0.0.0', '0000-00-00 00:00:00', 0, '985548104', '0', 'normal', '0', '0', '0000-00-00', '1', 0, 0, 0, '0000-00-00 00:00:00', 2592000, 0, 0, 0, '0', 0, '0', 0, 1, 'offline', '0000-00-00 00:00:00', 'normal', 'live', 0, 0, 0, 0, 0, 0, 1, '', ''),
(8886, 1766650463, 57740, 'Bhffh', 'MGpPaVRCWWpTaXZlalZ1Q0NYMlZydz09', 'e13e9ad1fc729af343a5604bd6c477ee', 'Bhffh@email.com', 'Reseller User', '2025-11-25 11:12:32', '0.0.0.0', '0000-00-00 00:00:00', 0, '516414521', '0', 'reseller', '1', '0', '0000-00-00', '1', 0, 0, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '0', 0, '0', 20, 1, 'offline', '0000-00-00 00:00:00', 'reseller', 'live', 0, 0, 0, 0, 0, 0, 0, '', ''),
(8887, 1766850545, 57738, '27334', 'bm8yVm8yS25SeGJzcU5mQmVtLzJVUT09', '58f03e4be24a4ff9d2d3ba639f11fd6a', '27334gmail.com', 'Normal User', '2025-11-25 09:55:45', '0.0.0.0', '0000-00-00 00:00:00', 0, '627344633', '0', 'normal', '0', '0', '0000-00-00', '1', 0, 0, 0, '0000-00-00 00:00:00', 2592000, 0, 0, 0, '0', 0, '0', 0, 1, 'offline', '0000-00-00 00:00:00', 'normal', 'live', 0, 0, 0, 0, 0, 0, 0, '', ''),
(8888, 1766850587, 57737, '32877', 'd1ZNbFVFNlJsUzhtckNiYjczL3hqUT09', 'b5026aa7758dc0e6f85ddb75f754ed14', '32877gmail.com', 'Normal User', '2025-11-24 03:48:22', '0.0.0.0', '0000-00-00 00:00:00', 0, '637046905', '0', 'normal', '0', '0', '0000-00-00', '1', 0, 0, 0, '0000-00-00 00:00:00', 2592000, 0, 0, 0, '0', 0, '0', 0, 1, 'offline', '0000-00-00 00:00:00', 'normal', 'live', 0, 0, 0, 0, 0, 0, 1, '', ''),
(8889, 1766863608, 57736, 'reseller4', 'T0hMeXdyY2ZSNEVaYnFQMmdzT0g1Zz09', 'a14924931c754b304a39fdcab42ce806', 'reseller4@email.com', 'Reseller User', '2025-11-24 03:04:24', '::1', '2025-11-24 03:04:32', 0, '900663638', '0', 'reseller', '1', '0', '0000-00-00', '1', 0, 0, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '0', 0, '0', 1000000, 1, 'offline', '2025-11-24 03:04:32', 'reseller', 'live', 0, 0, 0, 0, 0, 0, 0, '', '');

-- Table `users_profile` --
CREATE TABLE `users_profile` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `profile_id` int(5) NOT NULL,
  `profile_fb` varchar(250) NOT NULL,
  `profile_address` varchar(255) NOT NULL,
  `profile_number` varchar(13) NOT NULL DEFAULT '0',
  `profile_image` varchar(255) NOT NULL,
  `first_name` varchar(55) CHARACTER SET latin1 NOT NULL,
  `last_name` varchar(55) CHARACTER SET latin1 NOT NULL,
  `bio_link` varchar(11) CHARACTER SET latin1 NOT NULL,
  `bdo` int(1) NOT NULL DEFAULT 0,
  `bitcoin` int(1) NOT NULL DEFAULT 0,
  `bpi` int(1) NOT NULL DEFAULT 0,
  `cebuana` int(1) NOT NULL DEFAULT 0,
  `gcash` int(1) NOT NULL DEFAULT 0,
  `lbc` int(1) NOT NULL DEFAULT 0,
  `lbp` int(1) NOT NULL DEFAULT 0,
  `meetup` int(1) NOT NULL DEFAULT 0,
  `mlkwartapadala` int(1) NOT NULL DEFAULT 0,
  `palawanexpress` int(1) NOT NULL DEFAULT 0,
  `paypal` int(1) NOT NULL DEFAULT 0,
  `prepaidload` int(1) NOT NULL DEFAULT 0,
  `rcbc` int(1) NOT NULL DEFAULT 0,
  `rdperapadala` int(1) NOT NULL DEFAULT 0,
  `smartmoney` int(1) NOT NULL DEFAULT 0,
  `unionbank` int(1) NOT NULL DEFAULT 0,
  `westernunion` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15345 DEFAULT CHARSET=utf8;

INSERT INTO `users_profile` (`id`, `profile_id`, `profile_fb`, `profile_address`, `profile_number`, `profile_image`, `first_name`, `last_name`, `bio_link`, `bdo`, `bitcoin`, `bpi`, `cebuana`, `gcash`, `lbc`, `lbp`, `meetup`, `mlkwartapadala`, `palawanexpress`, `paypal`, `prepaidload`, `rcbc`, `rdperapadala`, `smartmoney`, `unionbank`, `westernunion`) VALUES
(1, 1, '', 'Saudi Arabia', '8801874654595', '1762851060.png', 'Vollam', 'Azim', 'OHRXfXKZQ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 2, '', 'Saudi Arabia', '8801874654595', 'avatar-1.png', 'Azim', 'Developer', 'HKWfLXfbG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15339, 57734, '', '', '09123456789', '', 'Reseller', 'Account', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15340, 57736, '', '', '09123456789', '', 'Reseller', 'Account', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15341, 57740, '', '', '09123456789', '', 'Reseller', 'Account', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15342, 57745, '', '', '09123456789', '', 'Reseller', 'Account', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15343, 57750, '', '', '09123456789', '', 'Reseller', 'Account', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15344, 57752, '', '', '09123456789', '', 'Reseller', 'Account', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- Table `voucher_logs` --
CREATE TABLE `voucher_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_name` varchar(50) NOT NULL,
  `user_id` int(100) NOT NULL,
  `client_name` varchar(755) NOT NULL,
  `reseller_id` int(100) NOT NULL,
  `reseller_name` varchar(64) NOT NULL,
  `is_qty` int(11) NOT NULL DEFAULT 1,
  `is_used` int(1) NOT NULL,
  `date_used` datetime NOT NULL,
  `is_date` date NOT NULL,
  `category` enum('premium','vip','private') NOT NULL DEFAULT 'premium',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_name` (`code_name`)
) ENGINE=MyISAM AUTO_INCREMENT=226 DEFAULT CHARSET=latin1;

-- Table `vouchers` --
CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_name` varchar(50) NOT NULL,
  `user_id` int(100) NOT NULL,
  `client_name` varchar(755) NOT NULL,
  `reseller_id` int(100) NOT NULL,
  `reseller_name` varchar(64) NOT NULL,
  `is_qty` int(11) NOT NULL DEFAULT 1,
  `is_used` int(1) NOT NULL,
  `duration` bigint(50) NOT NULL DEFAULT 0,
  `gen_date` datetime NOT NULL,
  `date_used` datetime NOT NULL,
  `category` enum('premium','vip','private') NOT NULL DEFAULT 'premium',
  `permission` tinyint(1) NOT NULL DEFAULT 0,
  `ipaddress` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_name` (`code_name`)
) ENGINE=MyISAM AUTO_INCREMENT=6023 DEFAULT CHARSET=latin1;

